face_recognition package
========================

Module contents
---------------

.. automodule:: face_recognition.api
    :members:
    :undoc-members:
    :show-inheritance:
