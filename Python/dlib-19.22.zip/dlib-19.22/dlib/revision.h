#ifndef DLIB_REVISION_H
// Version:  19.22
// Date:     Sun Mar 28 09:17:49 EDT 2021
// Git Changeset ID:  70ea028f12e10f4d992a0c4f0169749eae5bb185
#define DLIB_MAJOR_VERSION  19
#define DLIB_MINOR_VERSION  22
#define DLIB_PATCH_VERSION  0
#endif
