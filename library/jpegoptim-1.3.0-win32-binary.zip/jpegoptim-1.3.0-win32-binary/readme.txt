Title
-----

Windows version of
Jpegoptim v1.3.0  Copyright (c)  Timo Kokkonen, 1996,2013.

Windows build by Sergey Pushkin


Installation and using
----------------------

Installation is not needed, just unzip and run.

File name wildcard example:

jpegoptim "c:\long path\with spaces"\*.jpg



Homes
-----

Original version:
http://www.kokkonen.net/tjko/projects.html

Source GIT:
https://github.com/tjko/jpegoptim

This version on Sourceforge.net:
https://sourceforge.net/projects/jpegoptim

Source SVN:
https://svn.code.sf.net/p/jpegoptim/code/jpegoptim-1.3.0/trunk
